import codecs

with codecs.open('index.html.bak', 'r', 'utf-8') as f:
    content = f.read()

has_refresh = "refreshReportQueue" in content
print(f"Has refresh in bak: {has_refresh}")
