import re

with open('index.html', 'r', encoding='utf-8') as f:
    c = f.read()

# Find the app-shell opening
app_shell_idx = c.find('<div id="app-shell"')
app_shell_line = c[:app_shell_idx].count('\n') + 1

# Find the nav
nav_start = c.find('<nav class="omnis-top-nav">')
nav_end = c.find('</nav>', nav_start) + len('</nav>')
nav_line = c[:nav_start].count('\n') + 1
nav_end_line = c[:nav_end].count('\n') + 1

# Find the aside
aside_start = c.find('<aside class="sidebar">')
aside_end = c.find('</aside>', aside_start) + len('</aside>')
aside_line = c[:aside_start].count('\n') + 1
aside_end_line = c[:aside_end].count('\n') + 1

# Find the main
main_start = c.find('<main class="main">')
main_line = c[:main_start].count('\n') + 1

# Find view-dashboard
vd_start = c.find('id="view-dashboard"')
vd_line = c[:vd_start].count('\n') + 1

# Find topbar inside dashboard
topbar_start = c.find('<div class="topbar">', main_start)
topbar_end = c.find('</div>', topbar_start)  # First closing div - this is wrong, topbar has nested divs
topbar_line = c[:topbar_start].count('\n') + 1

# Find KPI section
kpi_idx = c.find('kpi-', main_start)
kpi_line = c[:kpi_idx].count('\n') + 1

print(f"LAYOUT STRUCTURE:")
print(f"  app-shell opens at line {app_shell_line}")
print(f"  nav starts at line {nav_line}, ends at line {nav_end_line} ({nav_end - nav_start} chars)")
print(f"  *** GAP between nav end and aside: {aside_start - nav_end} chars ***")
print(f"  aside starts at line {aside_line}, ends at line {aside_end_line} ({aside_end - aside_start} chars)")
print(f"  main starts at line {main_line}")
print(f"  view-dashboard at line {vd_line}")
print(f"  topbar at line {topbar_line}")
print(f"  first KPI at line {kpi_line}")
print()

# Show what's between nav end and aside start
gap = c[nav_end:aside_start]
print(f"Content between </nav> and <aside>:")
print(repr(gap[:500]))
print()

# Check if there's anything between aside end and main start
gap2 = c[aside_end:main_start]
print(f"\nContent between </aside> and <main> ({len(gap2)} chars):")
print(repr(gap2[:200]))

# How many lines in the sidebar?
print(f"\nSidebar HTML: {aside_end_line - aside_line} lines, {aside_end - aside_start} chars")
