# -*- coding: utf-8 -*-
import codecs

with codecs.open('index.html', 'r', 'utf-8') as f:
    content = f.read()

has_frappe_bd = 'get_ft_breakdown_overview' in content
print(f"Has get_ft_breakdown_overview: {has_frappe_bd}")
