import codecs

with codecs.open('index.html', 'r', 'utf-8') as f:
    content = f.read()

lines = content.split('\n')
for i, line in enumerate(lines):
    if "async function loadFtBreakdownDashboard()" in line:
        print("\n".join(lines[i:i+60]))
        break
