import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
f = open(r'C:\Users\Administrator\omnis\systems\fleetrack\index.html', encoding='utf-8')
content = f.read()
f.close()
checks = [
    ('view-rpt-machine-reg HTML',    'id="view-rpt-machine-reg"'),
    ('view-rpt-due-service HTML',    'id="view-rpt-due-service"'),
    ('view-rpt-gdr HTML',            'id="view-rpt-gdr"'),
    ('view-rpt-sts HTML',            'id="view-rpt-sts"'),
    ('view-rpt-wbd HTML',            'id="view-rpt-wbd"'),
    ('view-rpt-mwr HTML',            'id="view-rpt-mwr"'),
    ('view-rpt-wwu HTML',            'id="view-rpt-wwu"'),
    ('loadRptMachineReg fn',         'async function loadRptMachineReg()'),
    ('loadRptDueService fn',         'async function loadRptDueService()'),
    ('loadRptGdr fn',                'async function loadRptGdr()'),
    ('loadRptSts fn',                'async function loadRptSts()'),
    ('loadRptWbd fn',                'async function loadRptWbd()'),
    ('loadRptMwr fn',                'async function loadRptMwr()'),
    ('loadRptWwu fn',                'async function loadRptWwu()'),
    ('showView wired machine-reg',   "viewId === 'view-rpt-machine-reg'"),
    ('CSV export fn',                'function exportRptCsv('),
    ('Sort fn',                      'function initRptSort('),
    ('Filter fn',                    'function filterRptTable('),
    ('rpt-view-wrap CSS',            '.rpt-view-wrap {'),
    ('rpt-table CSS',                '.rpt-table {'),
]
all_ok = True
for label, needle in checks:
    found = needle in content
    if not found: all_ok = False
    print(f'{"OK" if found else "MISSING":<8} {label}')
print()
print('All checks passed!' if all_ok else 'Some MISSING — review above')
