import codecs
import re

with codecs.open('block_10706.js', 'r', 'utf-8') as f:
    content = f.read()

lines = content.split('\n')
for i, line in enumerate(lines):
    if "async function loadFtBreakdownDashboard" in line:
        start = i
    if "async function loadFtMachineRegister" in line:
        end = i + 100
        print(f"Found missing code from {start} to {end}")
        break
