// Copyright (c) 2023, Percival Rapha and contributors
// For license information, please see license.txt

frappe.ui.form.on('FT Track Component', {
	// refresh: function(frm) {

	// }
});
