# Copyright (c) 2022, Percival Rapha and contributors
# For license information, please see license.txt

import frappe
from frappe.model.document import Document


class FTWarrantyClaim(Document):
    # noinspection PyUnresolvedReferences
    def autoname(self):
        self.name = f"{self.description}-{frappe.generate_hash('', 3)}"
