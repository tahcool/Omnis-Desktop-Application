// Copyright (c) 2022, Percival Rapha and contributors
// For license information, please see license.txt

frappe.ui.form.on('FT Region', {
	// refresh: function(frm) {

	// }
});
