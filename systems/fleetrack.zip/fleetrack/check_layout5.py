import re

with open('index.html', 'r', encoding='utf-8') as f:
    c = f.read()

# Find all .main CSS rules (but not .main-content, .main-header etc)
matches = list(re.finditer(r'(?<!\w)\.main\s*\{([^}]*)\}', c))
print(f"Found {len(matches)} '.main' CSS rules:")
for i, m in enumerate(matches):
    line = c[:m.start()].count('\n') + 1
    print(f"\n--- Rule {i} at line {line} ---")
    print(m.group(0)[:400])

# Also find <main class="main"> to see if it has inline styles
main_tag = re.search(r'<main\s+class="main"[^>]*>', c)
if main_tag:
    line = c[:main_tag.start()].count('\n') + 1
    print(f"\n--- <main> tag at line {line} ---")
    print(main_tag.group(0))

# Check the dropdown CSS
dropdown_rules = list(re.finditer(r'\.top-nav-dropdown-menu\s*\{([^}]*)\}', c))
print(f"\nFound {len(dropdown_rules)} dropdown-menu CSS rules:")
for i, m in enumerate(dropdown_rules):
    line = c[:m.start()].count('\n') + 1
    print(f"\n--- Dropdown Rule {i} at line {line} ---")
    print(m.group(0)[:300])

# Check for margin-top on dropdown
dropdown_hover = list(re.finditer(r'\.top-nav-dropdown:hover\s+\.top-nav-dropdown-menu\s*\{([^}]*)\}', c))
print(f"\nFound {len(dropdown_hover)} dropdown hover rules:")
for i, m in enumerate(dropdown_hover):
    line = c[:m.start()].count('\n') + 1
    print(f"\n--- Hover Rule {i} at line {line} ---")
    print(m.group(0)[:300])
