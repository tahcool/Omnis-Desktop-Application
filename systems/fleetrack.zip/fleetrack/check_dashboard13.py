import codecs

with codecs.open('index.html', 'r', 'utf-8') as f:
    content = f.read()

has_dashboard = "async function loadFtBreakdownDashboard" in content
has_machine = "async function loadFtMachineRegister" in content
has_powertrack = "ptz_powertrack" in content
lines_count = len(content.split('\n'))

print(f"Lines: {lines_count}")
print(f"Dashboard: {has_dashboard}")
print(f"Machine: {has_machine}")
print(f"Powertrack: {has_powertrack}")
