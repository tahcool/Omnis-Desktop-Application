import re

with open('index.html', 'r', encoding='utf-8') as f:
    c = f.read()

# Let me check if the ISR view overlay is causing problems
# The ISR was injected as a fullscreen fixed overlay
isr_refs = list(re.finditer(r'view-isr', c))
print(f"view-isr references: {len(isr_refs)}")

# Check if there's a login screen or splash screen with height
login_refs = list(re.finditer(r'id="login|id="splash|id="preload', c))
print(f"Login/splash/preload screens: {len(login_refs)}")
for m in login_refs:
    line = c[:m.start()].count('\n') + 1
    tag = c[m.start():m.start()+200]
    print(f"  Line {line}: {tag[:100]}")

# Check the actual first 10 children of <main class="main">
main_idx = c.find('<main class="main">')
chunk = c[main_idx:main_idx+200]
print(f"\nFirst content in main:")
print(chunk.encode('ascii','replace').decode('ascii'))

# Check if view-dashboard has any siblings BEFORE it that might be visible
# Between main and view-dashboard
between = c[main_idx + len('<main class="main">'):c.find('id="view-dashboard"', main_idx)]
between_stripped = between.strip()
print(f"\nBetween <main> and view-dashboard ({len(between_stripped)} chars):")
print(repr(between_stripped[:200]))

# Check if there's a LOGIN overlay or any fullscreen overlay
overlay_divs = list(re.finditer(r'<div[^>]*(?:id|class)="[^"]*(?:login|overlay|splash|preload|loading)[^"]*"', c, re.IGNORECASE))
print(f"\nOverlay/login/splash divs: {len(overlay_divs)}")
for m in overlay_divs:
    line = c[:m.start()].count('\n') + 1
    print(f"  Line {line}: {m.group(0)[:120]}")

# Check the ISR view content and see if it has position:fixed
isr_div = re.search(r'<div[^>]*id="view-isr"[^>]*>', c)
if isr_div:
    line = c[:isr_div.start()].count('\n') + 1
    print(f"\nview-isr at line {line}: {isr_div.group(0)}")
    
# Check for any element with height:100vh that could create the gap
vh_heights = list(re.finditer(r'height\s*:\s*100vh', c[:5000]))
print(f"\nheight:100vh in first 5000 chars: {len(vh_heights)}")
for m in vh_heights:
    line = c[:m.start()].count('\n') + 1
    start = max(0, m.start()-80)
    ctx = c[start:m.end()+10].encode('ascii','replace').decode('ascii').replace('\n',' ')
    print(f"  Line {line}: ...{ctx}...")
