import codecs

with codecs.open('index.html', 'r', 'utf-8') as f:
    content = f.read()

lines = content.split('\n')
for i in range(6970, 6985):
    print(f"{i+1}: {lines[i].strip()}")
