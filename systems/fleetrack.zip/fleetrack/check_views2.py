import re

with open('index.html', 'r', encoding='utf-8') as f:
    c = f.read()

# Find the <main class="main"> tag
main_idx = c.find('<main class="main">')
main_line = c[:main_idx].count('\n') + 1

# Find the first view-page div (that's where dashboard content ends)
first_view = re.search(r'<div\s+id="view-archives"', c)
first_view_line = c[:first_view.start()].count('\n') + 1

print(f"<main> starts at line {main_line}")
print(f"First view-page (view-archives) at line {first_view_line}")
print(f"Dashboard content spans lines {main_line} to {first_view_line}")

# Show what's just before the first view-page div
before_first_view = c[first_view.start()-200:first_view.start()]
print(f"\nContent just before view-archives:")
print(before_first_view.encode('ascii', 'replace').decode('ascii'))

# Check if showView handles the dashboard case
sv_idx = c.find('function showView')
sv_block = c[sv_idx:sv_idx+1200].encode('ascii', 'replace').decode('ascii')
print(f"\nFull showView function:")
print(sv_block)

# Find view-dashboard references
refs = [(c[:m.start()].count('\n')+1, m.group(0)) for m in re.finditer(r'view-dashboard', c)]
print(f"\nAll 'view-dashboard' references ({len(refs)}):")
for line, txt in refs:
    print(f"  Line {line}")
