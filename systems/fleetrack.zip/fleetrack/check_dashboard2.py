import codecs

with codecs.open('index.html', 'r', 'utf-8') as f:
    content = f.read()

lines = content.split('\n')
for i, line in enumerate(lines):
    if "loadFtBreakdownDashboard" in line:
        print(f"Line {i+1}: {line.strip()}")
