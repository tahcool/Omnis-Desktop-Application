import re

with open('index.html', 'r', encoding='utf-8') as f:
    c = f.read()

# Find ALL .sidebar CSS rules and show each one
sidebar_rules = list(re.finditer(r'\.sidebar\s*\{([^}]*)\}', c))
print(f"Found {len(sidebar_rules)} .sidebar CSS rules:\n")
for i, m in enumerate(sidebar_rules):
    line_num = c[:m.start()].count('\n') + 1
    print(f"--- Rule {i} at line {line_num} (char {m.start()}) ---")
    print(m.group(0)[:300])
    print()

# Also check for any inline style on the sidebar element
sidebar_html = re.search(r'<aside[^>]*class="sidebar"[^>]*>', c)
if sidebar_html:
    print(f"\nSidebar HTML tag: {sidebar_html.group(0)}")

# Check if the .main-content has margin-left set by the original CSS
main_rules = list(re.finditer(r'\.main-content\s*\{([^}]*)\}', c))
print(f"\nFound {len(main_rules)} .main-content CSS rules:")
for i, m in enumerate(main_rules):
    line_num = c[:m.start()].count('\n') + 1
    print(f"--- Rule {i} at line {line_num} ---")
    print(m.group(0)[:300])
    print()

# Check the original sidebar CSS to understand what layout it defines
orig_sidebar = re.search(r'\.sidebar\s*\{[^}]*width[^}]*\}', c)
if orig_sidebar:
    line_num = c[:orig_sidebar.start()].count('\n') + 1
    print(f"\nOriginal sidebar with width at line {line_num}:")
    print(orig_sidebar.group(0)[:400])
