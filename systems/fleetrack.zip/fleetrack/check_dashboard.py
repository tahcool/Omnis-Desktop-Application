import codecs

with codecs.open('index.html', 'r', 'utf-8') as f:
    content = f.read()

has_powertrack = 'ptz_powertrack' in content
has_dashboard_func = 'loadFtBreakdownDashboard' in content

print(f"Has Powertrack: {has_powertrack}")
print(f"Has Dashboard Func: {has_dashboard_func}")
