import re

with open('index.html', 'r', encoding='utf-8') as f:
    c = f.read()

# Check for .topbar rules
topbar_rules = list(re.finditer(r'\.topbar\s*\{([^}]*)\}', c))
print(f"Found {len(topbar_rules)} .topbar CSS rules:")
for i, m in enumerate(topbar_rules):
    line_num = c[:m.start()].count('\n') + 1
    print(f"--- Rule {i} at line {line_num} ---")
    print(m.group(0)[:300])
    print()

# Check for duplicate hide CSS blocks
hide_count = c.count('/* --- HIDE LEGACY NAVBAR AND TOPBAR --- */')
print(f"\nDuplicate HIDE LEGACY blocks: {hide_count}")

# Check .app-shell rules  
app_shell_rules = list(re.finditer(r'\.app-shell\s*\{([^}]*)\}', c))
print(f"\nFound {len(app_shell_rules)} .app-shell CSS rules:")
for i, m in enumerate(app_shell_rules):
    line_num = c[:m.start()].count('\n') + 1
    print(f"--- Rule {i} at line {line_num} ---")
    print(m.group(0)[:300])
    print()
