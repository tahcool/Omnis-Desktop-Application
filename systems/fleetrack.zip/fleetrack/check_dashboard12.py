import codecs

with codecs.open('index.html', 'r', 'utf-8') as f:
    content = f.read()

print(f"Has refreshReportQueue: {'refreshReportQueue' in content}")
