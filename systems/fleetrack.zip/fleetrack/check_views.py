import re

with open('index.html', 'r', encoding='utf-8') as f:
    c = f.read()

# Find all view-page divs
views = list(re.finditer(r'<div\s+id="(view-[^"]+)"[^>]*class="[^"]*view-page[^"]*"', c))
print(f"Found {len(views)} view-page divs:")
for m in views:
    line = c[:m.start()].count('\n') + 1
    print(f"  Line {line}: id=\"{m.group(1)}\"")

# Find the showView function
sv_idx = c.find('function showView')
if sv_idx > 0:
    line = c[:sv_idx].count('\n') + 1
    chunk = c[sv_idx:sv_idx+800].encode('ascii', 'replace').decode('ascii')
    print(f"\nshowView function at line {line}:")
    print(chunk)
else:
    # Try window.showView
    sv_idx = c.find('window.showView')
    if sv_idx > 0:
        line = c[:sv_idx].count('\n') + 1
        chunk = c[sv_idx:sv_idx+800].encode('ascii', 'replace').decode('ascii')
        print(f"\nwindow.showView at line {line}:")
        print(chunk)

# Find if dashboard is in a view-page div
dash_idx = c.find('id="view-dashboard"')
if dash_idx > 0:
    line = c[:dash_idx].count('\n') + 1
    start = max(0, dash_idx - 100)
    chunk = c[start:dash_idx+200].encode('ascii', 'replace').decode('ascii')
    print(f"\nview-dashboard context at line {line}:")
    print(chunk)
else:
    print("\nNO id='view-dashboard' found!")

# Check for hidden class
hidden_css = list(re.finditer(r'\.hidden\s*\{([^}]*)\}', c))
print(f"\nFound {len(hidden_css)} .hidden CSS rules:")
for m in hidden_css:
    line = c[:m.start()].count('\n') + 1
    print(f"  Line {line}: {m.group(0)[:100]}")

# Check what's inside the main tag that is NOT in a view-page
main_idx = c.find('<main class="main">')
if main_idx > 0:
    # Find the first child elements
    after_main = c[main_idx:main_idx+500].encode('ascii', 'replace').decode('ascii')
    print(f"\nContent after <main class='main'>:")
    print(after_main)
