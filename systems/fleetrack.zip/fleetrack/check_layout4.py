import re

with open('index.html', 'r', encoding='utf-8') as f:
    c = f.read()

# Find what comes after </aside> (the sidebar)
idx = c.find('</aside>')
if idx > 0:
    chunk = c[idx:idx+400]
    # Sanitize for output
    chunk = chunk.encode('ascii', 'replace').decode('ascii')
    print("After </aside>:")
    print(chunk)
else:
    print("No </aside> found")

# Find the main content wrapper
# Look for common patterns
for pat in ['content-area', 'dashboard-content', 'view-dashboard', 'id="main"', 'class="main']:
    idx = c.find(pat)
    if idx > 0:
        line = c[:idx].count('\n') + 1
        print(f"\nFound '{pat}' at line {line}")

# Find what container holds the views
view_dash = c.find('id="view-dashboard"')
if view_dash > 0:
    start = max(0, view_dash - 200)
    chunk = c[start:view_dash+100].encode('ascii', 'replace').decode('ascii')
    print(f"\nContext before view-dashboard (line {c[:view_dash].count(chr(10))+1}):")
    print(chunk)
