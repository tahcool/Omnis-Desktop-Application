import codecs
import re

with codecs.open('index.html', 'r', 'utf-8') as f:
    content = f.read()

match = re.search(r'(<div id="view-reports" class="view-page hidden">.*?<!-- Content Area -->)(.*?)(</div>\s*</div>\s*</div>)', content, re.DOTALL)
if match:
    print("MATCH FOUND")
else:
    print("NOT FOUND")
