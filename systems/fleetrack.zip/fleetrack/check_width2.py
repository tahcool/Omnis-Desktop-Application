import re

with open('index.html', 'r', encoding='utf-8') as f:
    c = f.read()

# Check the app-shell div for inline styles
app_shell = re.search(r'<div\s+id="app-shell"[^>]*>', c)
if app_shell:
    line = c[:app_shell.start()].count('\n') + 1
    print(f"app-shell tag at line {line}: {app_shell.group(0)}")

# Check main tag for inline styles
main_tag = re.search(r'<main[^>]*class="main"[^>]*>', c)
if main_tag:
    line = c[:main_tag.start()].count('\n') + 1
    print(f"main tag at line {line}: {main_tag.group(0)}")

# Check aside/sidebar for inline styles
aside_tag = re.search(r'<aside[^>]*class="sidebar"[^>]*>', c)
if aside_tag:
    line = c[:aside_tag.start()].count('\n') + 1
    print(f"aside tag at line {line}: {aside_tag.group(0)}")

# Check if there's a max-width somewhere
maxw = list(re.finditer(r'max-width\s*:', c[:5000]))
print(f"\nmax-width in first 5000 chars: {len(maxw)}")
for m in maxw:
    line = c[:m.start()].count('\n') + 1
    end = c.find(';', m.start())
    print(f"  Line {line}: {c[m.start():end+1]}")

# Check the view-page CSS more carefully
vp_rules = list(re.finditer(r'\.view-page[^{]*\{([^}]*)\}', c))
print(f"\nAll view-page CSS ({len(vp_rules)}):")
for m in vp_rules:
    line = c[:m.start()].count('\n') + 1
    print(f"  Line {line}: {m.group(0)[:200]}")

# Check the Machines view specifically (what's shown in the screenshot)
machines_idx = c.find('id="view-machines"')
if machines_idx > 0:
    line = c[:machines_idx].count('\n') + 1
    tag = re.search(r'<div[^>]*id="view-machines"[^>]*>', c)
    print(f"\nview-machines tag at line {line}: {tag.group(0) if tag else 'not found'}")
    # Show what follows
    chunk = c[machines_idx:machines_idx+500].encode('ascii','replace').decode('ascii')
    print(chunk)

# The real issue: look for grid or layout in the view-dashboard or its parent
vd_idx = c.find('id="view-dashboard"')
if vd_idx > 0:
    line = c[:vd_idx].count('\n') + 1
    tag = re.search(r'<div[^>]*id="view-dashboard"[^>]*>', c)
    print(f"\nview-dashboard tag at line {line}: {tag.group(0) if tag else 'not found'}")

# Check if there's any fixed positioning issue or ISR overlay
isr_overlay = list(re.finditer(r'position\s*:\s*fixed', c[:10000]))
print(f"\nposition:fixed in first 10000 chars: {len(isr_overlay)}")
for m in isr_overlay:
    line = c[:m.start()].count('\n') + 1
    # Get containing rule
    rule_start = c.rfind('{', 0, m.start())
    selector_start = max(0, c.rfind('\n', 0, rule_start))
    selector = c[selector_start:rule_start].strip()
    print(f"  Line {line}: {selector}")
