import re

with open('index.html', 'r', encoding='utf-8') as f:
    c = f.read()

# 1. Find ALL grid-template-columns references
grid_refs = list(re.finditer(r'grid-template-columns', c))
print(f"grid-template-columns references: {len(grid_refs)}")
for m in grid_refs:
    line = c[:m.start()].count('\n') + 1
    start = max(0, m.start()-80)
    end = min(len(c), m.end()+80)
    ctx = c[start:end].encode('ascii','replace').decode('ascii').replace('\n',' ').replace('\r','')
    print(f"  Line {line}: ...{ctx}...")

# 2. Find ALL display: grid references
grid_display = list(re.finditer(r'display\s*:\s*grid', c))
print(f"\ndisplay: grid references: {len(grid_display)}")
for m in grid_display:
    line = c[:m.start()].count('\n') + 1
    start = max(0, m.start()-100)
    end = min(len(c), m.end()+20)
    ctx = c[start:end].encode('ascii','replace').decode('ascii').replace('\n',' ').replace('\r','')
    print(f"  Line {line}: ...{ctx}...")

# 3. Find any JS that modifies app-shell style
js_shell = list(re.finditer(r'app-shell[^"\']*style', c))
print(f"\nJS modifying app-shell style: {len(js_shell)}")
for m in js_shell:
    line = c[:m.start()].count('\n') + 1
    start = max(0, m.start()-20)
    end = min(len(c), m.end()+100)
    ctx = c[start:end].encode('ascii','replace').decode('ascii').replace('\n',' ').replace('\r','')
    print(f"  Line {line}: ...{ctx}...")

# 4. Find any JS that modifies sidebar display
js_sidebar = list(re.finditer(r'sidebar[^"\']*(?:style|display|classList)', c))
print(f"\nJS modifying sidebar: {len(js_sidebar)}")
for m in js_sidebar:
    line = c[:m.start()].count('\n') + 1
    start = max(0, m.start()-20)
    end = min(len(c), m.end()+100)
    ctx = c[start:end].encode('ascii','replace').decode('ascii').replace('\n',' ').replace('\r','')
    print(f"  Line {line}: ...{ctx}...")

# 5. Check for sidebar toggle JS
toggle_refs = list(re.finditer(r'sidebar.*toggle|toggle.*sidebar|collapsed', c, re.IGNORECASE))
print(f"\nSidebar toggle references: {len(toggle_refs)}")
for m in toggle_refs:
    line = c[:m.start()].count('\n') + 1
    start = max(0, m.start()-30)
    end = min(len(c), m.end()+80)
    ctx = c[start:end].encode('ascii','replace').decode('ascii').replace('\n',' ').replace('\r','')
    print(f"  Line {line}: ...{ctx}...")
