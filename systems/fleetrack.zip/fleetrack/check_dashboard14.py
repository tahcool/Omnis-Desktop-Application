import codecs

with codecs.open('index.html', 'r', 'utf-8') as f:
    content = f.read()

has_refresh = "refreshReportQueue" in content
has_powertrack = "ptz_powertrack" in content
print(f"Has refresh: {has_refresh}")
print(f"Has Powertrack: {has_powertrack}")
