import re

with open('index.html', 'r', encoding='utf-8') as f:
    c = f.read()

print('view-dashboard div exists:', 'id="view-dashboard" class="view-page"' in c)

views = re.findall(r'id="(view-[^"]+)"[^>]*class="[^"]*view-page', c)
print(f'Total view-page containers: {len(views)}')
print('Views:', views)

# Check showView handles view-dashboard
sv_idx = c.find('function showView')
sv_block = c[sv_idx:sv_idx+600]
print('\nshowView function:')
print(sv_block.encode('ascii', 'replace').decode('ascii'))
