import codecs

with codecs.open('isr_block.js', 'r', 'utf-8') as f:
    content = f.read()

# Let's see the start and end of loadFieldServicePlan
import re
match = re.search(r'async function loadFieldServicePlan\(\) \{.*?(?=async function|function|\/\*\*|\/\/ ---)', content, re.DOTALL)
if match:
    print("Found loadFieldServicePlan!")
    print(match.group(0)[:500])
else:
    print("loadFieldServicePlan not found")
