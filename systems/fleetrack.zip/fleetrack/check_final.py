import re

with open('index.html', 'r', encoding='utf-8') as f:
    c = f.read()

# Show all .main CSS rules (only in the main stylesheet, not embedded reports)
first_style_end = c.find('</style>')
main_css = c[:first_style_end]

main_rules = list(re.finditer(r'\.main\s*\{([^}]*)\}', main_css))
print(f"=== .main CSS rules in main stylesheet ({len(main_rules)}) ===")
for i, m in enumerate(main_rules):
    line = main_css[:m.start()].count('\n') + 1
    print(f"\n--- Rule {i} at line {line} ---")
    print(m.group(0))

# Show body rules
body_rules = list(re.finditer(r'body\s*\{([^}]*)\}', main_css))
print(f"\n=== body CSS rules in main stylesheet ({len(body_rules)}) ===")
for i, m in enumerate(body_rules):
    line = main_css[:m.start()].count('\n') + 1
    print(f"\n--- Rule {i} at line {line} ---")
    print(m.group(0))

# Show app-shell rules
as_rules = list(re.finditer(r'\.app-shell\s*\{([^}]*)\}', main_css))
print(f"\n=== .app-shell CSS rules in main stylesheet ({len(as_rules)}) ===")
for i, m in enumerate(as_rules):
    line = main_css[:m.start()].count('\n') + 1
    print(f"\n--- Rule {i} at line {line} ---")
    print(m.group(0))

# Show sidebar rules
sb_rules = list(re.finditer(r'\.sidebar\s*\{([^}]*)\}', main_css))
print(f"\n=== .sidebar CSS rules in main stylesheet ({len(sb_rules)}) ===")
for i, m in enumerate(sb_rules):
    line = main_css[:m.start()].count('\n') + 1
    print(f"\n--- Rule {i} at line {line} ---")
    print(m.group(0)[:200])
