import re

with open('index.html', 'r', encoding='utf-8') as f:
    c = f.read()

# Check all CSS that could affect width/margin of the content area
# Look for margin-left, padding-left, left, width on relevant selectors
patterns = [
    (r'\.main\s*\{([^}]*)\}', '.main'),
    (r'\.app-shell\s*\{([^}]*)\}', '.app-shell'),
    (r'body\s*\{([^}]*)\}', 'body'),
    (r'\.view-page\s*\{([^}]*)\}', '.view-page'),
]

for pat, name in patterns:
    matches = list(re.finditer(pat, c))
    for i, m in enumerate(matches):
        line = c[:m.start()].count('\n') + 1
        print(f"--- {name} rule {i} at line {line} ---")
        print(m.group(0)[:400])
        print()

# Check for any margin-left or padding-left with sidebar-width
ml_matches = list(re.finditer(r'margin-left\s*:\s*(?:var\(--sidebar-width\)|260px|240px)', c))
print(f"\nmargin-left with sidebar width: {len(ml_matches)} matches")
for m in ml_matches:
    line = c[:m.start()].count('\n') + 1
    ctx = c[max(0,m.start()-80):m.end()+20]
    print(f"  Line {line}: ...{ctx.encode('ascii','replace').decode('ascii')}...")

# Check for left: var(--sidebar-width)
left_matches = list(re.finditer(r'left\s*:\s*(?:var\(--sidebar-width\)|260px|240px)', c))
print(f"\nleft with sidebar width: {len(left_matches)} matches")
for m in left_matches:
    line = c[:m.start()].count('\n') + 1
    ctx = c[max(0,m.start()-80):m.end()+20]
    print(f"  Line {line}: ...{ctx.encode('ascii','replace').decode('ascii')}...")

# Check for width: calc(100% - sidebar)
calc_matches = list(re.finditer(r'width\s*:\s*calc\([^)]*sidebar', c))
print(f"\nwidth calc with sidebar: {len(calc_matches)} matches")
for m in calc_matches:
    line = c[:m.start()].count('\n') + 1
    print(f"  Line {line}: {m.group(0)}")
