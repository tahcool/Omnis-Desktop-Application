import re

with open('index.html', 'r', encoding='utf-8') as f:
    c = f.read()

print("=== LAYOUT DIAGNOSTIC ===")
print(f"File size: {len(c)} bytes")
print(f"omnis-top-nav present: {'omnis-top-nav' in c}")
print(f"HIDE LEGACY CSS present: {'HIDE LEGACY NAVBAR' in c}")
print(f"sidebar class count: {c.count('class=' + chr(34) + 'sidebar' + chr(34))}")
print(f".sidebar display:none CSS: {'.sidebar { display: none' in c}")
print(f"sidebar HTML block present: {'<aside' in c and 'sidebar' in c}")

# Check what's actually in the CSS for sidebar
sidebar_css_matches = [m.start() for m in re.finditer(r'\.sidebar\s*\{', c)]
print(f"sidebar CSS rule locations: {sidebar_css_matches}")

# Check what's in the CSS for .main-content margin-left
mc_matches = re.findall(r'\.main-content\s*\{[^}]*\}', c)
for i, m in enumerate(mc_matches):
    print(f"main-content CSS rule {i}: {m[:200]}")

# Check if sidebar HTML exists
sidebar_html_idx = c.find('class="sidebar"')
if sidebar_html_idx > 0:
    print(f"\nSidebar HTML found at char {sidebar_html_idx}")
    # Show surrounding context
    start = max(0, sidebar_html_idx - 50)
    end = min(len(c), sidebar_html_idx + 200)
    print(f"Context: ...{c[start:end]}...")
